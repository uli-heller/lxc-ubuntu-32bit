#define __xstrtol xstrtoul
#define __strtol_t unsigned long int
#define __spec "lu"
#include "test-xstrtol.c"
